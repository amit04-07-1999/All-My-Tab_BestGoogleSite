document.addEventListener("DOMContentLoaded", () => {
  const targetURL = "https://allmytab.com/search";
  window.location.replace(targetURL);
});
